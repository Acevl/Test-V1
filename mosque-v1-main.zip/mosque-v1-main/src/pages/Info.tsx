import { MapPin, Phone, Mail } from "lucide-react";
import { Card } from "@/components/ui/card";

const Info = () => {
  return (
    <div className="min-h-full bg-gray-50 pb-28">
      <div className="container mx-auto px-4 py-6">
        <Card className="bg-white/95 backdrop-blur-lg shadow-sm border border-gray-100 rounded-lg overflow-hidden">
          <div className="aspect-video relative">
            <img
              src="https://i.ibb.co/12ZJS0W/mosque.jpg"
              alt="Mosque"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <h1 className="absolute bottom-4 left-4 text-2xl font-bold text-white">
              Bristol Jamia Mosque
            </h1>
          </div>
          <div className="p-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-mosque-text">
                <MapPin className="h-5 w-5 text-mosque-primary flex-shrink-0" />
                <span>Bristol Jamia Mosque, Totterdown, Bristol, BS3 4UB</span>
              </div>
              <div className="flex items-center space-x-3 text-mosque-text">
                <Phone className="h-5 w-5 text-mosque-primary flex-shrink-0" />
                <span>+1 234 567 890</span>
              </div>
              <div className="flex items-center space-x-3 text-mosque-text">
                <Mail className="h-5 w-5 text-mosque-primary flex-shrink-0" />
                <span>contact@mosque.com</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Info;