import { HelpCircle, FileText, Settings } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useContext } from "react";
import { SheetClose } from "@/components/ui/sheet";

const menuItems = [
  {
    icon: HelpCircle,
    label: "Getting Started",
    path: "/getting-started",
  },
  {
    icon: FileText,
    label: "Usage Guide",
    path: "/guide",
  },
  {
    icon: Settings,
    label: "Settings",
    path: "/settings",
  },
];

export const NavigationMenu = () => {
  const navigate = useNavigate();

  return (
    <nav
      className="py-6 pb-safe translate-y-[34px] mt-[env(safe-area-inset-top)]"
      style={{
        paddingBottom: "env(safe-area-inset-bottom)",
      }}
    >
      <div className="space-y-2">
        {menuItems.map((item) => (
          <SheetClose key={item.path} asChild>
            <Link
              to={item.path}
              className="flex items-center gap-3 px-4 py-2 text-mosque-text hover:bg-mosque-secondary/50 rounded-lg transition-colors"
            >
              <item.icon className="h-5 w-5 text-mosque-primary" />
              <span>{item.label}</span>
            </Link>
          </SheetClose>
        ))}
      </div>
    </nav>
  );
};
