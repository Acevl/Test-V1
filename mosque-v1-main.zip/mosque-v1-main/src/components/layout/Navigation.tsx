import { Clock, Info } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const navItems = [
  { icon: Clock, label: "Prayers", path: "/" },
  { icon: Info, label: "Info", path: "/info" },
];

export const Navigation = () => {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 backdrop-blur-md bg-white/75 border-t border-gray-200 pb-safe">
      <div className="container mx-auto px-4">
        <div className="flex justify-around -mb-2">
          {navItems.map(({ icon: Icon, label, path }) => (
            <Link
              key={path}
              to={path}
              className={`flex flex-col items-center p-2 transition-colors min-w-[64px] ${
                location.pathname === path
                  ? "text-mosque-primary"
                  : "text-gray-500"
              }`}
            >
              <Icon className="h-6 w-6" />
              <span className="text-xs mt-1">{label}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};