import { Menu } from "lucide-react"; 
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { NavigationMenu } from "./NavigationMenu";

export const Header = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="bg-mosque-primary pt-safe">
        <div className="container mx-auto px-4 h-16 flex items-center">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20 -ml-2"
              >
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent 
              side="left" 
              className="w-[250px] bg-white/95 backdrop-blur-lg pt-safe"
              style={{ 
                position: 'fixed',
                top: 0,
                bottom: 0,
                height: '100%'
              }}
            >
              <NavigationMenu />
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};